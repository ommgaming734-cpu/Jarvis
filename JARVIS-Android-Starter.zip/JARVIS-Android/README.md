# JARVIS Android

A starter Android voice-and-text AI assistant with a cinematic orange circular HUD.

## What is included

- Kotlin + Jetpack Compose Android app
- Animated orange HUD with rotating arcs and pulsing core
- Speech-to-text through Android's speech recognizer
- Spoken replies through Android Text-to-Speech
- Text chat
- Node.js backend that keeps the OpenAI API key off the phone

## Requirements

- Android Studio (current stable)
- Android SDK 35
- JDK 17 (Android Studio can use its bundled JDK)
- Node.js 18 or newer for the backend
- An OpenAI API key and API billing enabled

AI API usage may incur charges. Ask a parent/guardian before enabling billing or adding a payment method. Never share your API key.

## 1. Start the backend

Open a terminal in the `backend` folder:

```bash
npm install
```

Copy `.env.example` to `.env`, then put your API key in `.env`:

```env
OPENAI_API_KEY=your_real_key_here
OPENAI_MODEL=gpt-5.5
PORT=3000
```

Start it:

```bash
npm start
```

You should see `JARVIS backend listening on port 3000`.

Keep `.env` private. Do not upload it to GitHub or put the key in Android code.

## 2. Open the Android app

1. Open Android Studio.
2. Choose **Open** and select this `JARVIS-Android` folder.
3. Wait for Gradle sync to finish.
4. Run the `app` configuration on an emulator or Android phone.
5. Allow microphone permission when prompted.

## 3. Connect the phone to the backend

In `MainActivity.kt`, find `API_URL`.

- Android emulator: keep `http://10.0.2.2:3000/chat`.
- Physical Android phone on the same Wi-Fi: replace `10.0.2.2` with your computer's local network IP, for example `http://192.168.1.10:3000/chat`. Your firewall must allow the local connection.
- For use outside your home network: deploy the backend to a trusted hosting provider and use its **HTTPS** URL.

The app manifest permits cleartext HTTP for local development. For a production release, use HTTPS and set `android:usesCleartextTraffic="false"`.

## 4. Try it

Tap the central JARVIS button or the microphone icon and speak. You can also type in the message box and tap SEND. Toggle VOICE REPLIES to enable or disable spoken answers.

## Troubleshooting

- **Connection error:** confirm the backend is running and `API_URL` points to the correct host.
- **401 / authentication error:** check the server-side API key in `backend/.env`.
- **Model not found:** set `OPENAI_MODEL` to a model available to your API project.
- **No microphone:** allow microphone permission and check that Android speech recognition is available on the device.
- **No spoken reply:** check media volume and the device's text-to-speech settings.

## Important security notes

This is a starter project, not a production-hardened service. Before publishing it, add user authentication, request rate limits, abuse protection, HTTPS-only transport, and appropriate logging controls. Never embed a secret API key in the APK.
