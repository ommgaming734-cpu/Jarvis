package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Orange = Color(0xFFFF8A00)
private val Amber = Color(0xFFFFB347)
private val Deep = Color(0xFF07090D)
private val Panel = Color(0xFF111821)
private const val API_URL = "http://10.0.2.2:3000/chat"
// Android emulator: 10.0.2.2 points to your computer.
// For a real phone, replace this with your computer's LAN IP while testing,
// or your deployed HTTPS backend URL.

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(0.96f)
            }
        }
        setContent { JarvisApp(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMessage("assistant", "Good evening. JARVIS systems are online. How may I assist you?")
        )
    }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("SYSTEM ONLINE") }
    var busy by remember { mutableStateOf(false) }
    var speakReplies by remember { mutableStateOf(true) }

    fun sendMessage(raw: String) {
        val prompt = raw.trim()
        if (prompt.isEmpty() || busy) return
        messages.add(ChatMessage("user", prompt))
        input = ""
        busy = true
        status = "PROCESSING"
        scope.launch {
            try {
                val reply = withContext(Dispatchers.IO) { callJarvis(messages.toList()) }
                messages.add(ChatMessage("assistant", reply))
                if (speakReplies) onSpeak(reply)
                status = "SYSTEM ONLINE"
            } catch (e: Exception) {
                messages.add(ChatMessage("assistant", "I couldn't reach my AI service. Check your internet connection and backend settings."))
                status = "CONNECTION ERROR"
            } finally {
                busy = false
            }
        }
    }

    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasMicPermission = granted }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "VOICE INPUT UNAVAILABLE"
            return
        }
        if (!hasMicPermission) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status = "LISTENING..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status = "PROCESSING VOICE" }
            override fun onError(error: Int) { status = "SYSTEM ONLINE"; recognizer.destroy() }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                recognizer.destroy()
                status = "SYSTEM ONLINE"
                if (!spoken.isNullOrBlank()) sendMessage(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        recognizer.startListening(intent)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, secondary = Amber, background = Deep, surface = Panel
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Deep).padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Text("J.A.R.V.I.S.", color = Orange, fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
            Text("PERSONAL ARTIFICIAL INTELLIGENCE", color = Color(0xFF8B9AA9), fontSize = 9.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))
            HudCore(
                listening = status.startsWith("LISTENING"),
                busy = busy,
                onClick = { startListening() }
            )
            Text(status, color = if (status.contains("ERROR")) Color.Red else Amber, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("VOICE REPLIES", color = Color.LightGray, fontSize = 11.sp)
                Switch(checked = speakReplies, onCheckedChange = { speakReplies = it })
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    messages.clear()
                    messages.add(ChatMessage("assistant", "Conversation cleared. Ready when you are."))
                }) { Text("CLEAR CHAT", color = Orange, fontSize = 10.sp) }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                reverseLayout = false,
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { msg ->
                    val isUser = msg.role == "user"
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                    ) {
                        Text(if (isUser) "YOU" else "JARVIS", color = Orange, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        Surface(
                            color = if (isUser) Color(0xFF292016) else Panel,
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF75420F))
                        ) {
                            Text(msg.text, color = Color(0xFFE8EDF2), modifier = Modifier.padding(12.dp), fontSize = 14.sp)
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                        .background(Panel).padding(horizontal = 16.dp, vertical = 14.dp),
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { sendMessage(input) }),
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) Text("Ask JARVIS anything...", color = Color.Gray, fontSize = 14.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { sendMessage(input) },
                    enabled = !busy && input.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange),
                    contentPadding = PaddingValues(horizontal = 15.dp, vertical = 13.dp)
                ) { Text("SEND", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
                Spacer(Modifier.width(5.dp))
                IconButton(onClick = { startListening() }) {
                    Text("🎙", fontSize = 23.sp)
                }
            }
        }
    }
}

@Composable
fun HudCore(listening: Boolean, busy: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "hud")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart),
        label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = Modifier.size(220.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension * 0.43f
            drawCircle(Orange.copy(alpha = 0.10f), radius = r * 1.16f, center = c)
            drawCircle(Orange.copy(alpha = 0.75f), radius = r, center = c, style = Stroke(2.dp.toPx()))
            drawCircle(Orange.copy(alpha = 0.35f), radius = r * 0.83f, center = c, style = Stroke(1.dp.toPx()))
            drawCircle(Orange.copy(alpha = 0.22f), radius = r * 0.62f, center = c, style = Stroke(1.dp.toPx()))
            rotate(rotation, pivot = c) {
                drawArc(Orange, -35f, 75f, false, topLeft = Offset(c.x-r, c.y-r), size = androidx.compose.ui.geometry.Size(r*2, r*2), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Amber, 155f, 35f, false, topLeft = Offset(c.x-r*0.83f, c.y-r*0.83f), size = androidx.compose.ui.geometry.Size(r*1.66f, r*1.66f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Orange.copy(alpha = 0.7f), 15f, 25f, false, topLeft = Offset(c.x-r*0.62f, c.y-r*0.62f), size = androidx.compose.ui.geometry.Size(r*1.24f, r*1.24f), style = Stroke(2.dp.toPx()))
            }
            for (i in 0 until 36) {
                val a = Math.toRadians(i * 10.0)
                val inner = r * 1.02f
                val outer = if (i % 3 == 0) r * 1.12f else r * 1.07f
                drawLine(
                    Orange.copy(alpha = if (i % 3 == 0) 0.9f else 0.35f),
                    Offset(c.x + kotlin.math.cos(a).toFloat()*inner, c.y + kotlin.math.sin(a).toFloat()*inner),
                    Offset(c.x + kotlin.math.cos(a).toFloat()*outer, c.y + kotlin.math.sin(a).toFloat()*outer),
                    strokeWidth = if (i % 3 == 0) 2.dp.toPx() else 1.dp.toPx()
                )
            }
        }
        Box(
            modifier = Modifier.size((94 * pulse).dp).clip(CircleShape)
                .background(Orange.copy(alpha = if (listening || busy) 0.24f else 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Button(
                onClick = onClick,
                modifier = Modifier.size(76.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF281807)),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (listening) "LISTEN" else if (busy) "..." else "J", color = Amber, fontSize = 27.sp, fontWeight = FontWeight.Light)
            }
        }
    }
}

private fun callJarvis(history: List<ChatMessage>): String {
    val connection = (URL(API_URL).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
    }
    try {
        val body = JSONObject().put("messages", JSONArray().apply {
            history.takeLast(16).forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
        })
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (connection.responseCode !in 200..299) {
            throw IllegalStateException("Server error ${connection.responseCode}: $response")
        }
        return JSONObject(response).optString("reply", "I received an empty response.")
    } finally {
        connection.disconnect()
    }
}
