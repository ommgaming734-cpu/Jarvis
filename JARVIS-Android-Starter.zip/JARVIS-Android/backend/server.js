import "dotenv/config";
import express from "express";

const app = express();
app.use(express.json({ limit: "32kb" }));

const SYSTEM_PROMPT = `
You are JARVIS, a polished, friendly, highly capable personal AI assistant inspired
by a fictional cinematic computer assistant. Speak naturally and clearly.
Address the user respectfully. Be concise by default, explain when asked, and
use light dry wit occasionally. Never claim to control devices, access accounts,
or perform actions unless a connected tool actually did so. If you are unsure,
say so. Keep responses appropriate for a teenage user.
`;

app.get("/", (_req, res) => res.json({ status: "JARVIS backend online" }));

app.post("/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
    }

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => ["user", "assistant"].includes(m?.role) && typeof m?.content === "string")
      .slice(-16)
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

    if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
      return res.status(400).json({ error: "Send a user message." });
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.5",
        instructions: SYSTEM_PROMPT,
        input: safeMessages,
        max_output_tokens: 700,
        store: false
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI API error:", data);
      return res.status(response.status).json({ error: "The AI service returned an error." });
    }

    const reply = data.output
      ?.filter(item => item.type === "message")
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n") || "I could not generate a text response.";

    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => {
  console.log(`JARVIS backend listening on port ${port}`);
});
